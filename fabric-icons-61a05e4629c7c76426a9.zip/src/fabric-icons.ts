  // Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fabric-assets-license

// tslint:disable:max-line-length

import {
  IIconOptions,
  IIconSubset,
  registerIcons
} from '@uifabric/styling';

export function initializeIcons(
  baseUrl: string = '',
  options?: IIconOptions
): void {
  const subset: IIconSubset = {
    style: {
      MozOsxFontSmoothing: 'grayscale',
      WebkitFontSmoothing: 'antialiased',
      fontStyle: 'normal',
      fontWeight: 'normal',
      speak: 'none'
    },
    fontFace: {
      fontFamily: `"FabricMDL2Icons"`,
      src: `url('${baseUrl}fabric-icons-ccab2113.woff') format('woff')`
    },
    icons: {
      'Album': '\uE7AB',
      'ChevronDown': '\uE70D',
      'ChevronDownMed': '\uE972',
      'Contact': '\uE77B',
      'Diamond': '\uED02',
      'Download': '\uE896',
      'FabricFolder': '\uF0A9',
      'Feedback': '\uED15',
      'FolderHorizontal': '\uF12B',
      'Help': '\uE897',
      'Home': '\uE80F',
      'List': '\uEA37',
      'More': '\uE712',
      'OpenPane': '\uE8A0',
      'OpenPaneMirrored': '\uEA5B',
      'Photo2': '\uEB9F',
      'RecycleBin': '\uEF87',
      'ReminderGroup': '\uEBF8',
      'Search': '\uE721',
      'Settings': '\uE713',
      'Share': '\uE72D',
      'SortLines': '\uE9D0',
      'WaffleOffice365': '\uF4E0'
    }
  };

  registerIcons(subset, options);
}
